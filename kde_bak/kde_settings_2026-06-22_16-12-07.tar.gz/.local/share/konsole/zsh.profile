[Appearance]
ColorScheme=Breeze_blure
Font=FiraCode Nerd Font,16,-1,5,400,0,0,0,0,0,0,0,0,0,0,1

[General]
Name=zsh
Parent=FALLBACK/
TerminalColumns=105
TerminalRows=35
