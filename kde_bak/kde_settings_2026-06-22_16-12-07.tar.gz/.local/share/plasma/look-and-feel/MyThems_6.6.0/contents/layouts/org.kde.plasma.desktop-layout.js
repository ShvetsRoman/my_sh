var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
                {
                    "config": {
                    },
                    "geometry.height": 0,
                    "geometry.width": 0,
                    "geometry.x": 0,
                    "geometry.y": 0,
                    "plugin": "org.kde.plasma.trash",
                    "title": "Смітник"
                }
            ],
            "config": {
                "/": {
                    "ItemGeometries-1694x1059": "Applet-67:1608.24,886.593,80,96,0;",
                    "ItemGeometries-1745x1091": "Applet-67:1651.51,915.506,96,96,0;",
                    "ItemGeometries-1800x1125": "Applet-67:1680,944,96,96,0;",
                    "ItemGeometries-1920x1200": "",
                    "ItemGeometriesHorizontal": "Applet-67:1680,944,96,96,0;",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/General": {
                    "changedPositions": "{}",
                    "lastResolution": "1800x1125",
                    "positions": "{\"1800x1125\":[\"1\",\"16\"]}",
                    "sortMode": "-1"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "file:///usr/share/wallpapers/ColdRipple/",
                    "SlidePaths": "/home/roman/.local/share/wallpapers/,/usr/share/wallpapers/"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "839",
                            "DialogWidth": "1363"
                        },
                        "/General": {
                            "activationIndicator": "false",
                            "customButtonImage": "/home/roman/00_setup/icons/launcher/icon_1024x1024.png",
                            "floating": "true",
                            "launcherPosition": "2",
                            "numberOfRows": "4",
                            "useCustomButtonImage": "true",
                            "useSystemFontSettings": "true"
                        }
                    },
                    "plugin": "AndromedaLauncher"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/General": {
                            "launchers": "preferred://browser,applications:org.wezfurlong.wezterm.desktop,preferred://filemanager,applications:com.sayonara-player.Sayonara.desktop,applications:libreoffice-calc.desktop,applications:libreoffice-writer.desktop,applications:gimp.desktop,applications:org.inkscape.Inkscape.desktop,applications:systemsettings.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icontasks"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/": {
                            "formfactor": "0",
                            "immutability": "1",
                            "lastScreen": "-1",
                            "popupHeight": "452",
                            "popupWidth": "284",
                            "wallpaperplugin": ""
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "752",
                            "DialogWidth": "1085"
                        },
                        "/General": {
                            "icon": "folder-download",
                            "sortDesc": "true",
                            "sortMode": "2",
                            "url": "file:///home/roman/Downloads",
                            "useCustomIcon": "true"
                        }
                    },
                    "plugin": "org.kde.plasma.folder"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.trash"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.pager"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "height": 1.5833333333333333,
            "hiding": "normal",
            "location": "bottom",
            "maximumLength": 75,
            "minimumLength": 75,
            "offset": 0
        },
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                        "/": {
                            "popupHeight": "137",
                            "popupWidth": "216"
                        }
                    },
                    "plugin": "org.kde.plasma.shutdownorswitch"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.appmenu"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.panelspacer"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "451",
                            "popupWidth": "396"
                        },
                        "/Appearance": {
                            "dateDisplayFormat": "BelowTime",
                            "fontFamily": "Noto Sans [GOOG]",
                            "fontSize": "12",
                            "fontStyleName": "Regular",
                            "fontWeight": "400"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.showdesktop"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "height": 1.5833333333333333,
            "hiding": "normal",
            "location": "top",
            "maximumLength": 75,
            "minimumLength": 75,
            "offset": 0
        }
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
