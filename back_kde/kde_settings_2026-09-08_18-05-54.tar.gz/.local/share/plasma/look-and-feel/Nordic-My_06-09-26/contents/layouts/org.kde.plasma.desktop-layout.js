var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
                {
                    "config": {
                    },
                    "geometry.height": 0,
                    "geometry.width": 0,
                    "geometry.x": 0,
                    "geometry.y": 0,
                    "plugin": "org.kde.plasma.trash",
                    "title": "Смітник"
                }
            ],
            "config": {
                "/": {
                    "ItemGeometries-1694x1059": "Applet-67:1608.24,886.593,80,96,0;",
                    "ItemGeometries-1745x1091": "Applet-139:1584,880,96,96,0;",
                    "ItemGeometries-1800x1125": "Applet-67:1680,944,96,96,0;",
                    "ItemGeometries-1920x1200": "",
                    "ItemGeometriesHorizontal": "Applet-139:1584,880,96,96,0;",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "760",
                    "DialogWidth": "1134"
                },
                "/General": {
                    "changedPositions": "{\"desktop:/test\":[\"1745x1091\",\"0\",\"0\"]}",
                    "lastResolution": "1745x1091",
                    "positions": "{\"1745x1091\":[\"1\",\"16\",\"desktop:/chrome-dakpodcappfkondcgbmonmndfnnhngjl-Default.desktop\",\"0\",\"0\",\"desktop:/test\",\"0\",\"0\"],\"1800x1125\":[\"1\",\"16\"]}",
                    "previews": "false",
                    "sortMode": "-1"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "file:///usr/share/wallpapers/Horos/",
                    "SlidePaths": "/home/roman/.local/share/wallpapers/,/usr/share/wallpapers/"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "839",
                            "DialogWidth": "1363"
                        },
                        "/General": {
                            "activationIndicator": "false",
                            "customButtonImage": "/home/roman/00_setup/icons/launcher/icon_2.png",
                            "floating": "true",
                            "launcherPosition": "2",
                            "numberOfRows": "4",
                            "useCustomButtonImage": "true",
                            "useSystemFontSettings": "true"
                        }
                    },
                    "plugin": "AndromedaLauncher"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/General": {
                            "launchers": "preferred://browser,applications:kitty.desktop,applications:org.kde.krusader.desktop,preferred://filemanager,applications:deadbeef.desktop,applications:libreoffice-calc.desktop,applications:libreoffice-writer.desktop,applications:gimp.desktop,applications:org.inkscape.Inkscape.desktop,applications:systemsettings.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icontasks"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/": {
                            "formfactor": "0",
                            "immutability": "1",
                            "lastScreen": "-1",
                            "popupHeight": "468",
                            "popupWidth": "300",
                            "wallpaperplugin": ""
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "752",
                            "DialogWidth": "1085"
                        },
                        "/General": {
                            "icon": "folder-download",
                            "sortDesc": "true",
                            "sortMode": "2",
                            "url": "file:///home/roman/Downloads",
                            "useCustomIcon": "true"
                        }
                    },
                    "plugin": "org.kde.plasma.folder"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.trash"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.pager"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "height": 2.1,
            "hiding": "dodgewindows",
            "lengthMode": "fit",
            "location": "bottom",
            "maximumLength": 87.25,
            "minimumLength": 87.25,
            "offset": 0,
            "opacity": "translucent"
        },
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                        "/": {
                            "popupHeight": "137",
                            "popupWidth": "216"
                        }
                    },
                    "plugin": "org.kde.plasma.shutdownorswitch"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.appmenu"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.panelspacer"
                },
                {
                    "config": {
                        "/": {
                            "CurrentPreset": "org.kde.plasma.systemmonitor",
                            "popupHeight": "266",
                            "popupWidth": "379"
                        },
                        "/Appearance": {
                            "chartFace": "org.kde.ksysguard.piechart",
                            "title": "Загальне використання процесора",
                            "updateRateLimit": "1000"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/SensorColors": {
                            "cpu/all/usage": "129,161,193"
                        },
                        "/Sensors": {
                            "highPrioritySensorIds": "[\"cpu/all/usage\"]",
                            "lowPrioritySensorIds": "[\"cpu/all/cpuCount\",\"cpu/all/coreCount\"]",
                            "totalSensors": "[\"cpu/all/usage\"]"
                        },
                        "/org.kde.ksysguard.piechart/General": {
                            "rangeAuto": "false"
                        }
                    },
                    "plugin": "org.kde.plasma.systemmonitor"
                },
                {
                    "config": {
                        "/": {
                            "CurrentPreset": "org.kde.plasma.systemmonitor",
                            "popupHeight": "230",
                            "popupWidth": "411"
                        },
                        "/Appearance": {
                            "chartFace": "org.kde.ksysguard.piechart",
                            "showTitle": "true",
                            "title": "Максимальна температура процесора",
                            "updateRateLimit": "1000"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/SensorColors": {
                            "cpu/all/averageTemperature": "129,193,173",
                            "cpu/all/maximumTemperature": "129,178,193"
                        },
                        "/Sensors": {
                            "highPrioritySensorIds": "[\"cpu/all/maximumTemperature\"]",
                            "lowPrioritySensorIds": "[\"cpu/all/averageTemperature\"]",
                            "totalSensors": "[\"cpu/all/maximumTemperature\"]"
                        },
                        "/org.kde.ksysguard.piechart/General": {
                            "rangeAuto": "false"
                        }
                    },
                    "plugin": "org.kde.plasma.systemmonitor"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "491",
                            "popupWidth": "436"
                        },
                        "/Appearance": {
                            "dateDisplayFormat": "BelowTime",
                            "fontFamily": "Noto Sans [GOOG]",
                            "fontSize": "12",
                            "fontStyleName": "Regular",
                            "fontWeight": "400"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.showdesktop"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "height": 1.9,
            "hiding": "normal",
            "lengthMode": "fill",
            "location": "top",
            "maximumLength": 87.25,
            "minimumLength": 87.25,
            "offset": 0,
            "opacity": "translucent"
        }
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
