[Appearance]
ColorScheme=Nordic
Font=JetBrains Mono,16,-1,5,400,0,0,0,0,0,0,0,0,0,0,1,,0,0

[General]
Name=zsh
Parent=FALLBACK/
TerminalColumns=105
TerminalRows=35
